<?php
$massage= "";

if  ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username=  htmlspecialchars(trim($_POST['username']));
    $password= $_POST['password']; 
}

?>